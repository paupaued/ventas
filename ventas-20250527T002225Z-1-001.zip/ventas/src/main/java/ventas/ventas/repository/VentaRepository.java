package ventas.ventas.repository;

import java.util.List;
import java.util.ArrayList;
import org.springframework.stereotype.Repository;

import ventas.ventas.model.Venta;

@Repository
public class VentaRepository {


    //guarda las ventas
    private List<Venta> listaVentas = new ArrayList<>();

    public List<Venta> obtenerVentas() {

        return listaVentas;
    }

    //busca libros por id
    public Venta bucarPorId(int id) {
        for(Venta venta : listaVentas){
            if (venta.getId() == id){
                return venta;
            }
        }
        
        return null;
    }
    //guarda venta
    public Venta guardar(Venta ven) {
        listaVentas.add(ven);
        return ven;
    }

    //actualiza venta

    //eliminar venta
    public void eliminar(int id){
        listaVentas.removeIf(x -> x.getId() == id);
    }


}